package main.java.User;
public abstract class Shape {
    String color;
    double parameter;

    public abstract double getArea();
}
