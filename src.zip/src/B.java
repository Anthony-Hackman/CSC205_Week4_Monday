public class B extends A{
    String someVariable;

    public B(String someVariable) 
    {
        
    }
}