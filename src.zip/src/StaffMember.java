public class StaffMember extends User {
    String JobTitle;
    }

public StaffMember(String FirstName, String LastName) {
    super(FirstName, LastName);
}
